<?php
	include '../login.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Contest Page</title>
	<link rel="stylesheet" type="text/css" href="../semantic.min.css">
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
	<link rel="stylesheet" type="text/css" href="../css/icon.min.css">
	<style type="text/css">
		@media only screen and (min-width: 641px){
			#mobmenu{
				display: none;
			}
		}
		@media only screen and (max-width: 640px){
			#deskmenu{
				display: none;
			}
			#mobmenu{
				display: block;
			}
		}
	</style>
</head>
<body>
		<div id="mobshow" class="ui sidebar inverted vertical teal menu" style="margin-top:-5%;">
		<a href="#" class="item">Home</a>
		<a href="contest/" class="item">Contests</a>
		<a href="#" class="item">Practice</a>
		<a href="#" class="item">Profile</a>
		<a href="#" class="item">Discussion</a>
		<a href="#" class="item">Contact Us</a>
	</div>
	<button class="ui teal cirular button" id="mobmenu">M</button>
	<div class="ui inverted teal menu" id="deskmenu">
		<a href="../" class="item"><b><i class="home icon"></i> Home</b></a>
		<a href="#" class="item"><b><i class="calendar alternate icon"></i> Contests</b></a>
		<a href="#" class="item"><b><i class="code icon"></i> Practice</b></a>
		<a href="#" class="item"><b><i class="user icon"></i> Profile</b></a>
		<a href="#" class="item"><b><i class="comments icon"></i> Discussion</b></a>
		<a href="#" class="item"><b><i class="circle info icon"></i> Contact Us</b></a>
		<?php
			if (!empty($_SESSION)) {
				$name=$_SESSION["username"];
				echo "<a href='../logout.php' class='right floated item'><b><i class='signup icon'></i>Welcome! &nbsp;&nbsp;$name</b></a>";
			}else{
				echo "<a href='../' class='right floated item'><b><i class='signup icon'></i>Login</b></a>";
			}
		?>
	</div>
		<div class="ui raised segment container">
				<a href="sumprog/">1) Sum of Two</a>
		</div>
		<div class="ui raised segment container">
				<a href="sumprime/index.php?cid=1&qid=1&start_time='2019-03-05 16:35:17'">2) Sum of Prime</a>
		</div>
		<div class="ui raised segment container">
				<a href="sequence/">3) Sequence</a>
		</div>
		<div class="ui raised segment container">
				<a href="bits/">4) MCQS</a>
		</div>
		<!-- <div class="ui raised segment container">
				<a href="sumprog/">Practice on Compiler</a>
		</div> -->
		<!-- <div class="ui raised segment container">
				<a href="prime/">2) Prime number</a>
		</div>
		<div class="ui raised segment container">
				<a href="fibonacci/">3) Fibonacci</a>
		</div> -->
</body>
</html>