<?php
	$t=time();
	echo date("Y-m-d h:m:s");
?>
