<?php
	include '../../login.php';
	$score=0;
	$val=0;
	if (empty($_SESSION)) {
		header("Location: ../../index.php");
	}
	if (isset($_POST["q1"]) && isset($_POST["q2"]) &&  isset($_POST["q3"])) {
		$userid=$_POST["userid"];
		$q1=$_POST["q1"];
		$q2=$_POST["q2"];
		$q3=$_POST["q3"];
		$qu="select * from answers";
		$res=$con->query($qu);
		$row=$res->fetch_array();
		if($row[1]==$q1){
			$val+=1;
		}
		$row=$res->fetch_array();
		if($row[1]==$q2){
			$val+=1;
		}
		$row=$res->fetch_array();
		if($row[1]==$q2){
			$val+=1;
		}
		$score=$val*33;
		if ($score==99) {
			$score=100;
		}
		$sql="insert into mock_bits(userid,score,contest) values('$userid',$score,'mock_bits')";
		$r=$con->query($sql);
		if($r){
			echo "Thank You<br><br>";
		}else{
			echo "You have Already Submitted<br><br>";
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Contest</title>
	<link rel="stylesheet" type="text/css" href="../../css/semantic.min.css">
	<link rel="stylesheet" type="text/css" href="../../plugin/codemirror/lib/codemirror.css">
	<script type="text/javascript" src="../../js/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="../../plugin/codemirror/theme/eclipse.css">
	<style type="text/css">
		@media only screen and (min-width: 641px){
			#mobmenu{
				display: none;
			}
		}
		@media only screen and (max-width: 640px){
			#deskmenu{
				display: none;
			}
			#mobmenu{
				display: block;
			}
		}
	</style>
</head>
<body class="ui container" style="margin-top: 1%;">
	<a onclick="history.back(-1);"><button class="ui teal button">Back</button></a>
		<a href="data.php"><button class="ui teal button">Leader Board</button></a>
		<form method="post" action="#">
			<label>1) Which is Not Belongs to C ?</label><br><br>
			<input type="radio" name="q1" value="pragma"> <label> pragma</label>
			<input type="radio" name="q1" value="include"> <label> include</label>
			<input type="radio" name="q1" value="type"> <label> type</label><br><br><br>

			<label>2)*(*(a[0])) is it Correct ?</label><br>
			<input type="radio" name="q2" value="yes"> <label> Yes</label>
			<input type="radio" name="q2" value="no"> <label> No</label><br><br><br>
			
			<label>2)is it possible initialize variable without '=' equal operator ?</label><br>
			<input type="radio" name="q3" value="yes"> <label> Yes</label>
			<input type="radio" name="q3" value="no"> <label> No</label>
			<input type="hidden" name="userid" value=<?php echo $_SESSION["userid"];?>><br><br><br>
			<button class="ui blue button" type="submit">Submit</button>
		</form>
</body>
</html>		