#include <stdio.h>
int isprime(long long int n)
{
	long long int i;
	if(n<=0ll || n==1ll)
	return 0;
	else{
			for(i=2;i<n/2+1;i++)
			{	
				if(n%i==0ll)	
					return 0;
			}					
				return 1;
		}

}

int main()
{
	int i,n;
	long long int s=0;
	scanf("%d",&n);
	long long int a[n];
	
	for(i=0;i<n;i++)
	{
		scanf("%lld",&a[i]);
	}
		
	for(i=0;i<n;i++)
	{
		if(isprime(a[i]))
		{
			s+=a[i];
		}
	}
	
	printf("%d\n",s);
}