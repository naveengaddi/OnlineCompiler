<?php
	$host="localhost:3306";
	$user="root";
	$passwd="";
	$db="compiler";
	$count=0;
	$con=mysqli_connect($host,$user,$passwd,$db);
	if($con){
		$sql="select * from scores_mock1 where contest='Sum Prog' order by (score) desc";
		$r=$con->query($sql);
		echo "<link rel='stylesheet' type='text/css' href='../../css/semantic.min.css'>";
		echo "<br><br>
		";
		echo "";
		echo "<div class='ui container'>
		<a onclick='history.back(-1);'><button class='ui teal button'>Back</button></a>
		<div class='ui raised teal segment center aligned header'>Leader Board</div>
		"
		;
		echo "<table class='ui table'>
			<th>S.No</th>
			<th>ID NO.</th>
			<th>Score</th>
			<th>Program Name</th>
			<th>Date.</th>
		";
		while ($row=$r->fetch_array()) {
			if($count%2==0){
				$color="#d4e2f6";
			}else{
				$color="#ffffff";
			}
			echo "<tr style='background-color:$color'><td>".++$count."</td><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><tr>";
		}
		echo "</table>";
		echo "</div>";
	}
?>