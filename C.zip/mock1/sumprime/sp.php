<?php
	shell_exec("gcc f.c");
	$out=shell_exec("./a.out");
	echo $out;
?>