//Round Robin Program
#include <stdio.h>
struct process{
	char name;
	int bt,ct,tat,wt;
	float at;
}p[100];
//sort Based on Process arrival Time
void _sort(struct process p[],int n){
	int i,j;
	struct process temp;
	 for(i=0;i<n;i++){
	 	for(j=0;j<n;j++){
	 		if(p[i].at<p[j].at){
	 			temp=p[i];
	 			p[i]=p[j];
	 			p[j]=temp;
			 }
		 }
	 }
}
//we need to run while loop until all burst times =0
//checking all burst times 0 or not
int check(struct process p[],int n){
	int i;
	int c=0;
	for(i=0;i<n;i++){
		if(p[i].bt==0){
			c++;
		}else{
			return 0;
		}
	}
	if(c==n){
		return 1;
	}else{
		return 0;
	}
}
//utility function to calculate gantt chart length
int length(char gChart[]){
	int i=0;
	while(gChart[i]!='\0'){
		i++;
	}
	return i;
}
//function to print result ..modified struct contain 999 atime ,0 btime so we need to fill again copied values 
void print(struct process p[],int n,float acopy[],int bcopy[]){
	int i;
	//printf("\nP.N \t AT \t BT \t CT \t TAT \t WT \n");
	float avgT=0,avgW=0;
	for(i=0;i<n;i++){
		p[i].tat=p[i].ct-(int)acopy[i];
		p[i].wt=p[i].tat-bcopy[i];
		avgT+=p[i].tat;
		avgW+=p[i].wt;
	//	printf("\n%c \t %d \t %d \t %d \t %d \t %d \n",p[i].name,(int)acopy[i],bcopy[i],p[i].ct,p[i].tat,p[i].wt);
	}
	printf("\nAverage Turn Around Time is : %.3f\n",avgT/n);
	printf("\nAverage Waiting Time is : %.3f\n",avgW/n);
}
int main(){
	int i,n,tq=2;
	char gChart[1000];
	gChart[0]='\0';
	//printf("Enter No.of Processess\n");
	scanf("%d",&n);
	int bcopy[n];
	float acopy[n];
	//printf("Enter P.N\t AT \t BT\n");
	for(i=0;i<n;i++){
		scanf("\n%c%f%d",&p[i].name,&p[i].at,&p[i].bt);
	}
	for(i=0;i<n;i++){
		acopy[i]=p[i].at;bcopy[i]=p[i].bt;
	}
	_sort(p,n);
	int min=p[0].at;
	for(i=0;i<min;i++){
		gChart[i]='_';
	}
	while(check(p,n)!=1){
		_sort(p,n);
		int l = length(gChart);
		int m = p[0].bt < tq ? p[0].bt : tq;
		int u = l+m;
		int k;
		for(k=l;k<u;k++){
			gChart[k]=p[0].name;
		}
		gChart[k]='\0';
		p[0].bt=p[0].bt-m;
		if(p[0].bt==0){
			p[0].at=999;
			p[0].ct=k;
		}else{
			p[0].at=k+0.5;
			p[0].ct=k;
		}
	}
	int l=length(gChart);
	printf("\n");
	print(p,n,acopy,bcopy);
	printf("\nGantt Chart is :\n");
	for(i=0;i<l;i++){
		printf(" %c ",gChart[i]);
	}
	getch();
}
