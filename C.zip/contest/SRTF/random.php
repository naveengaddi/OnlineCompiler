<?php
	function randomString(){
	$char="abcdefghijklmnopqrstuvwxyz0123456789ABCEDFGHIJKLMNOPQRSTUVWXYZ";
	$len=strlen($char);
	$str="";
	for ($i=0; $i < $len; $i++) { 
		$str .=$char[rand(0,$len-1)];
	}
	return $str;
	}
	echo randomString();	
?>