<?php
	$code="";
	if(isset($_POST["code"])){
		$code=$_POST["code"];
		echo $code;	
	}
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Editor</title>
	<link rel="stylesheet" type="text/css" href="../plugin/codemirror/lib/codemirror.css">
</head>
<body>

		<br><br><br><br><br><br><br>
		<form action="editor.php" method="post">
			<textarea class="codemirror-textarea" name="code"><?php echo $code ?></textarea>
			<input type="submit" name="submit" value="run">	
		</form>
		<script type="text/javascript" src="../js/jquery.min.js"></script>
		<script type="text/javascript" src="../plugin/codemirror/lib/codemirror.js"></script>
		
		<script type="text/javascript">
			$(document).ready(function(){
				var code = $(".codemirror-textarea")[0];
				var editor = CodeMirror.fromTextArea(code,{
					lineNumbers : true
				});
			});
		</script>
</body>
</html>