<?php
	$code=$_POST["code"];
	echo $code;
?>