 <?php
 	$result="";
	$code="";
	include '../login.php';
 	if(!empty($_SESSION)){
 		if(!empty($_POST)){
			putenv("PATH=C:\Program Files (x86)\Dev-Cpp\MinGW64\bin");
			$CC="gcc";
			$code=$_POST["code"];
			$ip="input.txt";
			$input=file_get_contents($ip);
			$uid=$_POST["userid"];
			//creating userid exe file
			$out=$uid.".exe";
			//creating file with userid
			$filename_code=$uid.".c";
			$filename_in="input1.txt";
			$filename_error="error.txt";
			$executable = $uid.".exe";
			$file_out=$uid.".txt";
			$command = $CC." -lm ".$filename_code." -o ".$uid.".exe";
			$command_error=$command." 2>".$filename_error;
			$file_code=fopen($filename_code, "w+");
			fwrite($file_code, $code);
			fclose($file_code);
			exec("cals $executable /g everyone:f");
			exec("cals $filename_error /g everyone:f");
			shell_exec($command_error);
			$error=file_get_contents($filename_error);
			if(trim($error)==""){
				$out=$out." <".$ip;
				$time=5;
				//$result=shell_exec("timeout ".$time."s ".$out);
				$result=shell_exec($out);
				//$result=shell_exec("C:\Windows\System32\timeout.exe /t 5 $out");
				//exec(sprintf("C:\Windows\System32\timeout.exe /t %d %s", $time, $out), $result);
				file_put_contents($file_out,$result);
			}else{
				$result=$error;
				file_put_contents($file_out,$result);
			}
			$result_file=$uid."_result.txt";

			exec("del *.o");
			exec("del $executable");
		}	
 	}else{
 		header("Location: ../index.php");
 	}

	
?>
<!DOCTYPE html>
<html>
<head>
	<title>C-Compiler</title>
	<link rel="stylesheet" type="text/css" href="../css/semantic.min.css">
</head>
<body class="ui container" style="margin-top: 1%;">
	<div><pre style="background:#f0f0f0;">
		<h3>1) Program to Find Sum of Two given numbers?</h3>
		input:
			i)N number of Test Cases
			ii)a b two integer to calculate sum
		ouput:
			i) sum of a,b

		Ex:
			i/p:
				2
				5 6
				1 4
			o/p:
				11
				5
		</pre>
	</div>
	<form method="post">
		<label>Code Editor :</label><br>
		<textarea rows="20" cols="100" name="code"><?php echo $code?></textarea><br><br>
		<input type="hidden" name="userid" value=<?php echo $_SESSION["userid"];?>>
		<button type="submit" name="submit" class="ui blue button">Run</button>
		<label>Output : </label><br><br>
		<textarea rows="4" cols="100" disabled><?php echo $result ?></textarea>
		<textarea rows="4" cols="100" disabled><?php echo $output1 ?></textarea>
	</form>
</body>
</html>