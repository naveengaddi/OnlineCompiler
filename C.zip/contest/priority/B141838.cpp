#include<bits/stdc++.h>
using namespace std;
bool all_bts_zero(int bt[], int n)
{
	
	for(int i=1;i<=n;i++)
	  {
	  	if(bt[i]!=0)
	  	  return true;
	  }
	  return false;		
}

int minpri(int pr[], int bt[], int n)
{

	int min=10000000,index;
	for(int i=1;i<=n;i++)
	 {
	 	if(bt[i]!=0)
	 	 {
	 	 	if(pr[i]<min)
	 	 	 {
	 	 	 	min=pr[i];
	 	 	 	index=i;
			   }
		  }
	 }
	 return index;
}
	
	


int main()
{
	int n;
	cin>>n;
    int bt[n],pr[n],cbt[n];
   	char a[n];
	for(int i=1;i<=n;i++)
	{
	
	   cin>>a[i]>>pr[i]>>bt[i];
	   cbt[i]=bt[i];
   }
	   int k=0;
	   
	   
	   while(all_bts_zero(bt,n))
	   {
	   	 int index=minpri(pr,bt,n);
	   	 
	   	  int ll=k;
	   	  k+=bt[index];
	   	  bt[index]=0;
	   	
	   	cout<<a[index]<<" "<<k<<" "<<k<<" "<<(k-(cbt[index]))<<endl;
	   	
	   	  
	   	}
	  
	   	  
	  	return 0;
}