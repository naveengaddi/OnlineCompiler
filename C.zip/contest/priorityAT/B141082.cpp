#include<bits/stdc++.h>
using namespace std;
int all_bts_zero(int bt[], int n)
{
	for(int i=1;i<=n;i++)
	  {
	  	if(bt[i]!=0)
	  	  return 1;
	  }
	  return 0;
}

int funnn(int k, int pr[], int at[], int bt[], int n)
{
	int min=10000000,index;
	for(int i=1;i<=n;i++)
	 {
	 	  if(bt[i]!=0 && at[i]<=k)
	 	    {
	 	    	if(pr[i]<min)
	 	    	 {
	 	    	 	min=pr[i];
	 	    	 	index=i;
				  }
			 }
	 }
	 return index;
}

int fun1(int pr[], int bt[], int n)
{
		int min=10000000,index;
	for(int i=1;i<=n;i++)
	 {
	 	  if(bt[i]!=0)
	 	    {
	 	    	if(pr[i]<min)
	 	    	 {
	 	    	 	min=pr[i];
	 	    	 	index=i;
				  }
			 }
	 }
	 return index;
	
	
	
}

int main()
{
	int n;
	cin>>n;
	char arr[n];
	int pr[n],at[n],bt[n],cbt[n],ct[n];
	int min=10000000,max=0,index;
	for(int i=1;i<=n;i++)
	{
		cin>>arr[i]>>pr[i]>>at[i]>>bt[i];
		cbt[i]=bt[i];
		if(at[i]<min)
		{
			min=at[i];
			index=i;
		}
			if(at[i]>max)
		{
			max=at[i];
			
		}
	}

	int k=min;
	vector <int> vec;
	  while(all_bts_zero(bt,n))
   {
   	   if(k<max)
   	   {
   	   	
		  
	     if(bt[index]!=0)
	      {
	      	   bt[index]-=1;
	      	    k+=1;
	            if(bt[index]==0)
		         {
		          ct[index]=k;
		          vec.push_back(index);
	              }
		  }
		
	      index=funnn(k,pr,at,bt,n);
	
     }
     else
     {
     	if(bt[index]!=0)
     	{
     		k+=bt[index];
     		bt[index]=0;
     		ct[index]=k;
     		vec.push_back(index);
     		index=fun1(pr,bt,n);
		 }
	 }
   }
   
     for(int i=0;i<vec.size();i++)
      {
          int ind=vec[i];
		  cout<<arr[ind]<<" "<<ct[ind]<<" ";
		  int tat=ct[ind]-at[ind];
		  cout<<tat<<" "<<tat-cbt[ind]<<endl;	
	  }
	return 0;
}